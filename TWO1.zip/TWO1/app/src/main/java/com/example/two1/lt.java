package com.example.two1;

public class lt {      //建一个聊天记录的类   只需要words即可
    private String words;

    public lt(String words) {
        this.words = words;
    }

    public String getWords() {
        return words;
    }
}
