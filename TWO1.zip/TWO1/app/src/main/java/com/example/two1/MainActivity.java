package com.example.two1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<lt> words = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button fasong = findViewById(R.id.fasong);
        final EditText shuru = findViewById(R.id.shuru);
        final RecyclerView RC = findViewById(R.id.RC);
        final int[] num = {0};
        fasong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            words.add(new lt(shuru.getText().toString()));      //先添加进List
                shuru.setText("");            //再清空
                RC.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                lt_Adapter adapter = new lt_Adapter(words);
                num[0]++;  //添加适配器  最后输出
                RC.setAdapter(adapter);
            }
        });
    }
}