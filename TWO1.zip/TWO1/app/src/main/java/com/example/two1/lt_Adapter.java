package com.example.two1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class lt_Adapter extends RecyclerView.Adapter<lt_Adapter.ViewHolder> {   //为聊天记录建立recyclerview的适配器
    private List<lt> words;

    static class ViewHolder extends RecyclerView.ViewHolder{
        TextView WORDS;
        public ViewHolder(View view){
            super(view);
            WORDS = view.findViewById(R.id.WORDS);
        }
    }

    public lt_Adapter(List<lt> words){
        this.words = words;
    }

    @NonNull
    @Override
    public lt_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
      View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lt_item,parent,false);
      ViewHolder holder = new ViewHolder(view);
      return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull lt_Adapter.ViewHolder holder, int position) {
        lt lt = words.get(position);
        holder.WORDS.setText(lt.getWords().toString());
    }

    @Override
    public int getItemCount() {
        return words.size();
    }



}
