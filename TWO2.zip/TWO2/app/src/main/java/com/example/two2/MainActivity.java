package com.example.two2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button BT = findViewById(R.id.BT);

        BT.setOnClickListener(new View.OnClickListener() {     //设置监听器以及事件
            @Override
            public void onClick(View v) {
                AlertDialog.Builder DL =new AlertDialog.Builder(MainActivity.this);
                View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.fragment_denglu,null);  //将fragment 的布局放入view  再将view放入Mainactivity的点击事件中显示出来
                final EditText zhanghao,mima;
                zhanghao = (EditText) view.findViewById(R.id.zhanghao);      //这里需要通过view来查找fragment中的控件
                mima = (EditText) view.findViewById(R.id.mima);
                DL.setPositiveButton("登录", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    if((zhanghao.getText().toString()+"").equals("abc")&&((mima.getText().toString()+"").equals("123"))){
                        Toast.makeText(MainActivity.this,"登陆成功",Toast.LENGTH_SHORT).show();    //这里总是忘记.show()
                    }
                    else{
                        Toast.makeText(MainActivity.this,"登陆失败",Toast.LENGTH_SHORT).show();
                    }
                    }
                }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //取消则不做处理
                    }
                }).setView(view).show();
            }
        });

    }
}